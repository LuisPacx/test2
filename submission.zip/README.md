Backend coding exercise
=======================

You will need Node.js 16 (or more recent), which you can download at https://nodejs.org. Run:

```sh
yarn install
yarn start
```

This should open http://localhost:3000 in your browser, with has the instructions.

When you are happy with your solution, run:

```sh
yarn run archive
```

This will create a file named `submission.zip` in the project folder, which you can send back to us.
